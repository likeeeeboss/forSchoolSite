from django import forms
from .models import UserRegistration
from django.contrib.auth.forms import AuthenticationForm



class UserRegistrationForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput)

    class Meta:
        model = UserRegistration
        fields = ['first_name', 'last_name', 'email', 'password']



class CustomAuthenticationForm(AuthenticationForm):
    username = forms.CharField(label='Email', max_length=254)
    password = forms.CharField(label='Пароль', widget=forms.PasswordInput)