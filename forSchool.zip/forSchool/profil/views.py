from django.contrib.auth.hashers import make_password
from django.shortcuts import render, redirect
from .forms import UserRegistrationForm
from django.contrib import messages
from django.contrib.auth import authenticate, login
from django.contrib import messages
from .forms import CustomAuthenticationForm


def myAccount(request):
    return render(request, "profil/prof/myAccount.html")
#Страница входа в акк
def login(request):
    if request.method == 'POST':
        form = CustomAuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(request, username=username, password=password)
            if user is not None:
                login(request, user)
                messages.success(request, 'Вы успешно вошли в систему.')
                return redirect('profile')  # перенаправление на главную страницу
            else:
                messages.error(request, 'Неверный логин или пароль.')
    else:
        form = CustomAuthenticationForm()

    return render(request, 'profil/reg/login.html', {'form': form})




#Страница регистрации акка
def registration(request):
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)

        if form.is_valid():
            # Сохраните пароль в защищенном виде (хэширование)
            user = form.save(commit=False)
            user.password = make_password(form.cleaned_data['password'])
            user.save()
            messages.success(request, 'Регистрация прошла успешно!')
            return redirect('login')  # перенаправление на страницу входа
    else:
        form = UserRegistrationForm()

    return render(request, 'profil/reg/registration.html', {'form': form})
# Create your views here.
