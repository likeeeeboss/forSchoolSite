from .models import ImageUploadArch
from .models import ImageUploadAnim
from .models import ImageUploadCity
from .models import ImageUploadNature
from .models import ImageUploadPort
from .models import ImageUploadSky
from .models import ImageUploadSport
from .models import ImageUploadStillife
from .models import ImageUploadTech
from .models import ImageUploadTravel


from django.forms import ModelForm, TextInput, ImageField

class ArchForm(ModelForm):
    class Meta:
        model = ImageUploadArch
        fields = ['image']

class AnimForm(ModelForm):
    class Meta:
        model = ImageUploadAnim
        fields = ['image']

class cityForm(ModelForm):
    class Meta:
        model = ImageUploadCity
        fields = ['image']

class natureForm(ModelForm):
    class Meta:
        model = ImageUploadNature
        fields = ['image']

class portForm(ModelForm):
    class Meta:
        model = ImageUploadPort
        fields = ['image']

class skyForm(ModelForm):
    class Meta:
        model = ImageUploadSky
        fields = ['image']

class sportForm(ModelForm):
    class Meta:
        model = ImageUploadSport
        fields = ['image']

class stillForm(ModelForm):
    class Meta:
        model = ImageUploadStillife
        fields = ['image']

class techForm(ModelForm):
    class Meta:
        model = ImageUploadTech
        fields = ['image']

class travelForm(ModelForm):
    class Meta:
        model = ImageUploadTravel
        fields = ['image']


