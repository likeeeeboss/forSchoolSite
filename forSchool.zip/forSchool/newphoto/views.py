from django.http import HttpResponse
from django.shortcuts import render, redirect


from .forms import ArchForm
from .forms import AnimForm
from .forms import cityForm
from .forms import natureForm
from .forms import portForm
from .forms import stillForm
from .forms import skyForm
from .forms import sportForm
from .forms import techForm
from .forms import travelForm





def load(request):
    return render(request, "nphoto/site/loadChoice.html")

def loadAnim(request):
    error = ""
    if request.method == 'POST':
        form = AnimForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('animals')
        else:
            error = 'Форма была неверной'

    form = AnimForm()
    data = {'form': form,
            'error': error,
            }
    return render(request, "nphoto/site/loadPhoto/loadAnim.html", data)




def loadArch(request):
    error = ""
    if request.method == 'POST':
        form = ArchForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('ai')
        else:
            error = 'Форма была неверной'


    form = ArchForm()
    data ={'form':form,
           'error':error,
           }

    return render(request, "nphoto/site/loadPhoto/loadArch.html", data)


def loadCity(request):
    error = ""
    if request.method == 'POST':
        form = cityForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('city')
        else:
            error = 'Форма была неверной'

    form = cityForm()
    data = {'form': form,
            'error': error,
            }
    return render(request, "nphoto/site/loadPhoto/loadCity.html", data)

def loadNature(request):
    error = ""
    if request.method == 'POST':
        form = natureForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('nature')
        else:
            error = 'Форма была неверной'

    form = natureForm()
    data = {'form': form,
            'error': error,
            }
    return render(request, "nphoto/site/loadPhoto/loadNature.html" , data)

def loadPort(request):
    error = ""
    if request.method == 'POST':
        form = portForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('port')
        else:
            error = 'Форма была неверной'

    form = portForm()
    data = {'form': form,
            'error': error,
            }
    return render(request, "nphoto/site/loadPhoto/loadPort.html", data)

def loadSky(request):
    error = ""
    if request.method == 'POST':
        form = skyForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('scen')
        else:
            error = 'Форма была неверной'

    form = skyForm()
    data = {'form': form,
            'error': error,
            }
    return render(request, "nphoto/site/loadPhoto/loadSky.html", data)

def loadSport(request):
    error = ""
    if request.method == 'POST':
        form = sportForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('sport')
        else:
            error = 'Форма была неверной'

    form = sportForm()
    data = {'form': form,
            'error': error,
            }
    return render(request, "nphoto/site/loadPhoto/loadSport.html", data)

def loadStillife(request):
    error = ""
    if request.method == 'POST':
        form = stillForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('stil')
        else:
            error = 'Форма была неверной'

    form = stillForm()
    data = {'form': form,
            'error': error,
            }
    return render(request, "nphoto/site/loadPhoto/loadStillife.html", data)

def loadTech(request):
    error = ""
    if request.method == 'POST':
        form = techForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('tech')
        else:
            error = 'Форма была неверной'

    form = techForm()
    data = {'form': form,
            'error': error,
            }
    return render(request, "nphoto/site/loadPhoto/loadTechno.html", data)

def loadTravel(request):
    error = ""
    if request.method == 'POST':
        form =  travelForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('travel')
        else:
            error = 'Форма была неверной'

    form = travelForm()
    data = {'form': form,
            'error': error,
            }
    return render(request, "nphoto/site/loadPhoto/loadTravel.html", data)
