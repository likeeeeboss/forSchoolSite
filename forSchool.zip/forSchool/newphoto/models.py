from django.db import models



class ImageUploadArch(models.Model):
    image = models.ImageField(upload_to='uploaded_images/')
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Image {self.id} uploaded at {self.uploaded_at}"
    class Meta:
        verbose_name = 'Загрузка фото архтиктура'
        verbose_name_plural = 'Загрузка фото архитиктуры'



class ImageUploadAnim(models.Model):
    image = models.ImageField(upload_to='uploaded_images/')
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Image {self.id} uploaded at {self.uploaded_at}"
    class Meta:
        verbose_name = 'Загрузка фото животное'
        verbose_name_plural = 'Загрузка фото животных'



class ImageUploadCity(models.Model):
    image = models.ImageField(upload_to='uploaded_images/')
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Image {self.id} uploaded at {self.uploaded_at}"
    class Meta:
        verbose_name = 'Загрузка фото города'
        verbose_name_plural = 'Загрузка фото городов'



class ImageUploadNature(models.Model):
    image = models.ImageField(upload_to='uploaded_images/')
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Image {self.id} uploaded at {self.uploaded_at}"
    class Meta:
        verbose_name = 'Загрузка фото природы'
        verbose_name_plural = 'Загрузка фото природы'



class ImageUploadPort(models.Model):
    image = models.ImageField(upload_to='uploaded_images/')
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Image {self.id} uploaded at {self.uploaded_at}"
    class Meta:
        verbose_name = 'Загрузка фото портрета'
        verbose_name_plural = 'Загрузка фото портрета'




class ImageUploadSky(models.Model):
    image = models.ImageField(upload_to='uploaded_images/')
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Image {self.id} uploaded at {self.uploaded_at}"
    class Meta:
        verbose_name = 'Загрузка фото неба'
        verbose_name_plural = 'Загрузка фото небес'



class ImageUploadSport(models.Model):
    image = models.ImageField(upload_to='uploaded_images/')
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Image {self.id} uploaded at {self.uploaded_at}"
    class Meta:
        verbose_name = 'Загрузка фото спорт'
        verbose_name_plural = 'Загрузка фото спорта'



class ImageUploadStillife(models.Model):
    image = models.ImageField(upload_to='uploaded_images/')
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Image {self.id} uploaded at {self.uploaded_at}"
    class Meta:
        verbose_name = 'Загрузка фото натюрморт'
        verbose_name_plural = 'Загрузка фото натюрмортов'




class ImageUploadTech(models.Model):
    image = models.ImageField(upload_to='uploaded_images/')
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Image {self.id} uploaded at {self.uploaded_at}"
    class Meta:
        verbose_name = 'Загрузка фото технологии'
        verbose_name_plural = 'Загрузка фото технологии'



class ImageUploadTravel(models.Model):
    image = models.ImageField(upload_to='uploaded_images/')
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Image {self.id} uploaded at {self.uploaded_at}"
    class Meta:
        verbose_name = 'Загрузка фото путешествие'
        verbose_name_plural = 'Загрузка фото путешествий'