from django.contrib import admin

from .models import ImageUploadAnim
from .models import ImageUploadArch
from .models import ImageUploadCity
from .models import ImageUploadNature
from .models import ImageUploadPort
from .models import ImageUploadSport
from .models import ImageUploadSky
from .models import ImageUploadStillife
from .models import ImageUploadTech
from .models import ImageUploadTravel



admin.site.register(ImageUploadArch)
admin.site.register(ImageUploadAnim)
admin.site.register(ImageUploadCity)
admin.site.register(ImageUploadNature)
admin.site.register(ImageUploadPort)
admin.site.register(ImageUploadSport)
admin.site.register(ImageUploadSky)
admin.site.register(ImageUploadStillife)
admin.site.register(ImageUploadTech)
admin.site.register(ImageUploadTravel)
