from tkinter.font import names

from django.urls import path
from . import  views





urlpatterns = [
  path('', views.load, name="loadChoice"),
  path('loadArch', views.loadArch, name="loadArch"),
  path('loadAnim', views.loadAnim, name="loadAnim"),
  path('loadCity', views.loadCity, name="loadCity"),
  path('loadPort', views.loadPort, name="loadPort"),
  path('loadSky', views.loadSky, name="loadSky"),
  path('loadSport', views.loadSport, name="loadSport"),
  path('loadStil', views.loadStillife, name="loadStil"),
  path('loadNature', views.loadNature, name="loadNature"),
  path('loadTech', views.loadTech, name="loadTech"),
  path('loadTravel', views.loadTravel, name="loadTravel"),


]