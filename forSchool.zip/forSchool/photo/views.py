from django.http import HttpResponse
from django.shortcuts import render

from newphoto.models import ImageUploadArch
from newphoto.models import ImageUploadAnim
from newphoto.models import ImageUploadCity
from newphoto.models import ImageUploadNature
from newphoto.models import ImageUploadSky
from newphoto.models import ImageUploadSport
from newphoto.models import ImageUploadStillife
from newphoto.models import ImageUploadPort
from newphoto.models import ImageUploadTech
from newphoto.models import ImageUploadTravel



#Импорт базы данных

#Создание страниц-функций находиться тут

#Главная страница
def main(request):

    return render(request, "photo/site/main.html")

#Страница контактов
def about(request):

    return render(request, "photo/site/about.html")


#Архитектура и интрерьер
def archInt(request):
    base = ImageUploadArch.objects.all()
    return render(request, "photo/janr/archInt.html", {'base': base})


#Город
def city(request):
    base = ImageUploadCity.objects.all()
    return render(request, "photo/janr/city.html", {'base': base})


#Портреты
def portret(request):
    base = ImageUploadArch.objects.all()
    return render(request, "photo/janr/portret.html" , {'base': base})


#Животные
def animals(request):
    base = ImageUploadAnim.objects.all()
    return render(request, "photo/janr/animals.html", {'base': base})


#Природа
def nature(request):
    base = ImageUploadNature.objects.all()
    return render(request, "photo/janr/nature.html", {'base': base})


#Спорт
def sport(request):
    base = ImageUploadSport.objects.all()
    return render(request, "photo/janr/sport.html", {'base': base})


#Путешествия
def travel(request):
    base = ImageUploadTravel.objects.all()
    return render(request, "photo/janr/travel.html", {'base': base})


#Натюрморт
def stilLife(request):
    base = ImageUploadStillife.objects.all()
    return render(request, "photo/janr/stilLife.html", {'base': base})


#Пейзаж
def scenery(request):
    base = ImageUploadSky.objects.all()
    return render(request, "photo/janr/sky.html", {'base': base})


#Технологии
def techno(request):
    base = ImageUploadTech.objects.all()
    return render(request, "photo/janr/techno.html", {'base': base})






