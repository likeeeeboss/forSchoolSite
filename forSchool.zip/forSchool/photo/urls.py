from django.urls import path
from . import  views


urlpatterns = [
    # главаня страница и профиль
    path('', views.main, name='home'),
    path('about', views.about, name='about'),

    # страницы фото
    path('animals', views.animals, name='animals'),  # животные
    path('archint', views.archInt, name='ai'),  # архитектура
    path('city', views.city, name='city'),  # город
    path('nature', views.nature, name='nature'),  # природа
    path('portret', views.portret, name='port'),  # портрет
    path('scenery', views.scenery, name='scen'),  # пейзаж
    path('sport', views.sport, name='sport'),  # спорт
    path('stillife', views.stilLife, name='stil'),  # натюрморт
    path('techno', views.techno, name='tech'),  # техника
    path('travel', views.travel, name='travel'),  # путешествия
]